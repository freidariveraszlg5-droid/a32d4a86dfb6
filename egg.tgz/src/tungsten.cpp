// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Run integration suite"); }
int main(){
  announce();
  return lionss_run_workload("tungsten");
}
