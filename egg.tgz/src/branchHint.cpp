// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply branch hints"); }
int main(){
  announce();
  return lionss_run_workload("branchHint");
}
