// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Select ALPN protocol\n", stdout);
  return lionss_run_workload("alpnSelect");
}
