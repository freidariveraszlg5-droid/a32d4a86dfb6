// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Remap action bindings\n", stdout);
  return lionss_run_workload("inputRemap");
}
