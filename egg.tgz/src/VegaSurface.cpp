// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fit vega surface"); }
int main(){
  announce();
  return lionss_run_workload("VegaSurface");
}
