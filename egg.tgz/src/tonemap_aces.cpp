// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply ACES tonemap"); }
int main(){
  announce();
  return lionss_run_workload("tonemap_aces");
}
