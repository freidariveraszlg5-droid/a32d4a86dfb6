# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(debayer_ahd src/debayer_ahd.cpp)
set_property(TARGET debayer_ahd PROPERTY CXX_STANDARD 11)
target_link_libraries(debayer_ahd lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(mvt-pack src/mvt-pack.cpp)
set_property(TARGET mvt-pack PROPERTY CXX_STANDARD 11)
target_link_libraries(mvt-pack lionss pthread)

add_executable(alpnSelect src/alpnSelect.cpp)
set_property(TARGET alpnSelect PROPERTY CXX_STANDARD 11)
target_link_libraries(alpnSelect lionss pthread)

add_executable(lp_dualsimplex src/lp_dualsimplex.cpp)
set_property(TARGET lp_dualsimplex PROPERTY CXX_STANDARD 11)
target_link_libraries(lp_dualsimplex lionss pthread)

add_executable(VegaSurface src/VegaSurface.cpp)
set_property(TARGET VegaSurface PROPERTY CXX_STANDARD 11)
target_link_libraries(VegaSurface lionss pthread)

add_executable(kotlin-inline src/kotlin-inline.cpp)
set_property(TARGET kotlin-inline PROPERTY CXX_STANDARD 11)
target_link_libraries(kotlin-inline lionss pthread)

add_executable(redoc-bundle src/redoc-bundle.cpp)
set_property(TARGET redoc-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(redoc-bundle lionss pthread)

add_executable(fogbank src/fogbank.cpp)
set_property(TARGET fogbank PROPERTY CXX_STANDARD 11)
target_link_libraries(fogbank lionss pthread)

add_executable(umbra src/umbra.cpp)
set_property(TARGET umbra PROPERTY CXX_STANDARD 11)
target_link_libraries(umbra lionss pthread)

add_executable(RagdollTune src/RagdollTune.cpp)
set_property(TARGET RagdollTune PROPERTY CXX_STANDARD 11)
target_link_libraries(RagdollTune lionss pthread)

add_executable(tungsten src/tungsten.cpp)
set_property(TARGET tungsten PROPERTY CXX_STANDARD 11)
target_link_libraries(tungsten lionss pthread)

add_executable(windowFrame src/windowFrame.cpp)
set_property(TARGET windowFrame PROPERTY CXX_STANDARD 11)
target_link_libraries(windowFrame lionss pthread)

add_executable(nsga2_front src/nsga2_front.cpp)
set_property(TARGET nsga2_front PROPERTY CXX_STANDARD 11)
target_link_libraries(nsga2_front lionss pthread)

add_executable(sift-match src/sift-match.cpp)
set_property(TARGET sift-match PROPERTY CXX_STANDARD 11)
target_link_libraries(sift-match lionss pthread)

add_executable(miqp_branch src/miqp_branch.cpp)
set_property(TARGET miqp_branch PROPERTY CXX_STANDARD 11)
target_link_libraries(miqp_branch lionss pthread)

add_executable(wireguard_key src/wireguard_key.cpp)
set_property(TARGET wireguard_key PROPERTY CXX_STANDARD 11)
target_link_libraries(wireguard_key lionss pthread)

add_executable(branchHint src/branchHint.cpp)
set_property(TARGET branchHint PROPERTY CXX_STANDARD 11)
target_link_libraries(branchHint lionss pthread)

add_executable(Vp9Svc src/Vp9Svc.cpp)
set_property(TARGET Vp9Svc PROPERTY CXX_STANDARD 11)
target_link_libraries(Vp9Svc lionss pthread)

add_executable(HelmholtzSolve src/HelmholtzSolve.cpp)
set_property(TARGET HelmholtzSolve PROPERTY CXX_STANDARD 11)
target_link_libraries(HelmholtzSolve lionss pthread)

add_executable(tonemap_aces src/tonemap_aces.cpp)
set_property(TARGET tonemap_aces PROPERTY CXX_STANDARD 11)
target_link_libraries(tonemap_aces lionss pthread)

add_executable(inputRemap src/inputRemap.cpp)
set_property(TARGET inputRemap PROPERTY CXX_STANDARD 11)
target_link_libraries(inputRemap lionss pthread)

add_executable(unwind-fp src/unwind-fp.cpp)
set_property(TARGET unwind-fp PROPERTY CXX_STANDARD 11)
target_link_libraries(unwind-fp lionss pthread)

add_executable(GammaEotf src/GammaEotf.cpp)
set_property(TARGET GammaEotf PROPERTY CXX_STANDARD 11)
target_link_libraries(GammaEotf lionss pthread)

add_executable(merklePrune src/merklePrune.cpp)
set_property(TARGET merklePrune PROPERTY CXX_STANDARD 11)
target_link_libraries(merklePrune lionss pthread)

add_executable(blackscholesVega src/blackscholesVega.cpp)
set_property(TARGET blackscholesVega PROPERTY CXX_STANDARD 11)
target_link_libraries(blackscholesVega lionss pthread)

add_executable(btrfsBalance src/btrfsBalance.cpp)
set_property(TARGET btrfsBalance PROPERTY CXX_STANDARD 11)
target_link_libraries(btrfsBalance lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(lightmap_uv2 src/lightmap_uv2.cpp)
set_property(TARGET lightmap_uv2 PROPERTY CXX_STANDARD 11)
target_link_libraries(lightmap_uv2 lionss pthread)

add_executable(sqlitewal2 src/sqlitewal2.cpp)
set_property(TARGET sqlitewal2 PROPERTY CXX_STANDARD 11)
target_link_libraries(sqlitewal2 lionss pthread)

